﻿namespace BS
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Books));
            panel2 = new Panel();
            label8 = new Label();
            button1 = new Button();
            label3 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            label5 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            label6 = new Label();
            label7 = new Label();
            label9 = new Label();
            label10 = new Label();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            label11 = new Label();
            comboBox1 = new ComboBox();
            label12 = new Label();
            label13 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            comboBox2 = new ComboBox();
            button5 = new Button();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(button5);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label1);
            panel2.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            panel2.Location = new Point(298, 27);
            panel2.Name = "panel2";
            panel2.Padding = new Padding(5);
            panel2.Size = new Size(760, 675);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ControlDarkDark;
            label8.Location = new Point(720, 5);
            label8.Name = "label8";
            label8.Size = new Size(32, 34);
            label8.TabIndex = 11;
            label8.Text = "X";
            label8.Click += label8_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Indigo;
            button1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(104, 217);
            button1.Name = "button1";
            button1.Padding = new Padding(15);
            button1.Size = new Size(122, 59);
            button1.TabIndex = 9;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlDarkDark;
            label3.Location = new Point(164, 126);
            label3.Name = "label3";
            label3.Size = new Size(75, 23);
            label3.TabIndex = 8;
            label3.Text = "Author";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlDarkDark;
            label2.Location = new Point(23, 126);
            label2.Name = "label2";
            label2.Size = new Size(99, 23);
            label2.TabIndex = 7;
            label2.Text = "Book Title";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(164, 163);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(143, 36);
            textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(23, 163);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 36);
            textBox1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(365, 42);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(69, 82);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlDarkDark;
            label1.Location = new Point(320, 5);
            label1.Name = "label1";
            label1.Size = new Size(165, 34);
            label1.TabIndex = 1;
            label1.Text = "Book Shop ";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DimGray;
            panel1.Controls.Add(panel6);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(23, 27);
            panel1.Name = "panel1";
            panel1.Size = new Size(269, 675);
            panel1.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 23);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(64, 62);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.DimGray;
            label5.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(82, 38);
            label5.Name = "label5";
            label5.Size = new Size(165, 34);
            label5.TabIndex = 12;
            label5.Text = "Book Shop ";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(4, 8);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(64, 62);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(6, 9);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(64, 62);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(7, 8);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(64, 62);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 15;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(6, 4);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(64, 62);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 16;
            pictureBox6.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.DimGray;
            label6.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(110, 22);
            label6.Name = "label6";
            label6.Size = new Size(69, 34);
            label6.TabIndex = 17;
            label6.Text = "User";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.PaleGreen;
            label7.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(100, 19);
            label7.Name = "label7";
            label7.Size = new Size(100, 34);
            label7.TabIndex = 18;
            label7.Text = "Books ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.DimGray;
            label9.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(81, 21);
            label9.Name = "label9";
            label9.Size = new Size(174, 34);
            label9.TabIndex = 19;
            label9.Text = "Dashboard ";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.DimGray;
            label10.Font = new Font("Century Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(100, 17);
            label10.Name = "label10";
            label10.Size = new Size(124, 34);
            label10.TabIndex = 20;
            label10.Text = "Log Out";
            label10.Click += label10_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.PaleGreen;
            panel3.Controls.Add(label7);
            panel3.Controls.Add(pictureBox4);
            panel3.Location = new Point(6, 154);
            panel3.Name = "panel3";
            panel3.Size = new Size(255, 73);
            panel3.TabIndex = 21;
            // 
            // panel4
            // 
            panel4.BackColor = Color.DimGray;
            panel4.Controls.Add(label6);
            panel4.Controls.Add(pictureBox3);
            panel4.Location = new Point(8, 244);
            panel4.Name = "panel4";
            panel4.Size = new Size(252, 78);
            panel4.TabIndex = 22;
            // 
            // panel5
            // 
            panel5.BackColor = Color.DimGray;
            panel5.Controls.Add(label9);
            panel5.Controls.Add(pictureBox5);
            panel5.Location = new Point(5, 339);
            panel5.Name = "panel5";
            panel5.Size = new Size(255, 77);
            panel5.TabIndex = 23;
            // 
            // panel6
            // 
            panel6.BackColor = Color.DimGray;
            panel6.Controls.Add(label10);
            panel6.Controls.Add(pictureBox6);
            panel6.Location = new Point(6, 434);
            panel6.Name = "panel6";
            panel6.Size = new Size(253, 71);
            panel6.TabIndex = 24;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = SystemColors.ControlDarkDark;
            label11.Location = new Point(322, 126);
            label11.Name = "label11";
            label11.Size = new Size(116, 23);
            label11.TabIndex = 12;
            label11.Text = "Categories";
            label11.Click += label11_Click;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Programming", "Network", "Math", "Novels", "English" });
            comboBox1.Location = new Point(322, 164);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(162, 35);
            comboBox1.TabIndex = 13;
            comboBox1.Text = "Selects";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = SystemColors.ControlDarkDark;
            label12.Location = new Point(633, 126);
            label12.Name = "label12";
            label12.Size = new Size(57, 23);
            label12.TabIndex = 17;
            label12.Text = "Price";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = SystemColors.ControlDarkDark;
            label13.Location = new Point(492, 126);
            label13.Name = "label13";
            label13.Size = new Size(93, 23);
            label13.TabIndex = 16;
            label13.Text = "Quantity";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(633, 163);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(93, 36);
            textBox3.TabIndex = 15;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(492, 163);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(122, 36);
            textBox4.TabIndex = 14;
            // 
            // button2
            // 
            button2.BackColor = Color.Indigo;
            button2.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(251, 217);
            button2.Name = "button2";
            button2.Padding = new Padding(15);
            button2.Size = new Size(122, 59);
            button2.TabIndex = 18;
            button2.Text = "Edit";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Indigo;
            button3.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(400, 217);
            button3.Name = "button3";
            button3.Padding = new Padding(15);
            button3.Size = new Size(122, 59);
            button3.TabIndex = 19;
            button3.Text = "Remove";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Indigo;
            button4.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(552, 217);
            button4.Name = "button4";
            button4.Padding = new Padding(15);
            button4.Size = new Size(122, 59);
            button4.TabIndex = 20;
            button4.Text = "Reset";
            button4.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(21, 378);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(705, 289);
            dataGridView1.TabIndex = 21;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(320, 299);
            label4.Name = "label4";
            label4.Size = new Size(90, 23);
            label4.TabIndex = 22;
            label4.Text = "Book List";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Programming", "Network", "Math", "Novels", "English" });
            comboBox2.Location = new Point(299, 325);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(162, 31);
            comboBox2.TabIndex = 23;
            comboBox2.Text = "Selects";
            // 
            // button5
            // 
            button5.BackColor = Color.Indigo;
            button5.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(483, 304);
            button5.Name = "button5";
            button5.Padding = new Padding(15);
            button5.Size = new Size(102, 52);
            button5.TabIndex = 24;
            button5.Text = "Reset";
            button5.UseVisualStyleBackColor = false;
            // 
            // Books
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Indigo;
            ClientSize = new Size(1082, 714);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Books";
            Text = "Books";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Label label8;
        private Button button1;
        private Label label3;
        private Label label2;
        private TextBox textBox2;
        private TextBox textBox1;
        private PictureBox pictureBox1;
        private Label label1;
        private Panel panel1;
        private Label label5;
        private PictureBox pictureBox2;
        private Label label10;
        private Label label9;
        private Label label7;
        private Label label6;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Panel panel6;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private ComboBox comboBox1;
        private Label label11;
        private DataGridView dataGridView1;
        private Button button4;
        private Button button3;
        private Button button2;
        private Label label12;
        private Label label13;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label4;
        private Button button5;
        private ComboBox comboBox2;
    }
}